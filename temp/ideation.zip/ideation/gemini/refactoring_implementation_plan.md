# Refactoring Implementation Plan: Decomposing `application/shared`

This document provides a step-by-step plan for eliminating the `application/shared` anti-pattern. The goal is to move shared code into appropriate bounded contexts or a new, dedicated `infrastructure` library for truly cross-cutting concerns.

**Guiding Principles:**

- **Incremental Changes:** Each step should be a small, testable, and verifiable change.
- **Favor Duplication Over Wrong Abstraction:** When in doubt, duplicate code. It is better to have two independent components than one incorrect dependency.
- **Tests are Essential:** No code will be moved without corresponding tests. All tests must pass after each step.

---

## Phase 1: Relocating Core Infrastructure

**Objective:** Move genuinely cross-cutting components related to CQRS mechanics into a new, dedicated infrastructure location. These components are not domain-specific but are part of the application's core architecture.

**New Location:** `infrastructure/bus/`

### Step 1.1: Move Bus Interfaces and Implementations

1.  **Create Directory:** Create `C:/Heijunka/infrastructure/bus/`.
2.  **Move Files:**
    - Move `application/shared/interfaces/command_bus.py` to `infrastructure/bus/command_bus.py`
    - Move `application/shared/interfaces/query_bus.py` to `infrastructure/bus/query_bus.py`
    - Move `application/shared/implementations/base_bus.py` to `infrastructure/bus/base_bus.py`
    - Move `application/shared/implementations/simple_command_bus.py` to `infrastructure/bus/simple_command_bus.py`
    - Move `application/shared/implementations/simple_query_bus.py` to `infrastructure/bus/simple_query_bus.py`
3.  **Update Imports:** Search the entire codebase for imports pointing to the old locations and update them to the new `infrastructure.bus` path.
4.  **Run Tests:** Execute all tests to ensure the application still functions correctly.

### Step 1.2: Move Handlers and supporting code

1.  **Move Files:**
    - Move `application/shared/interfaces/command_handler.py` to `infrastructure/bus/command_handler.py`
    - Move `application/shared/interfaces/query_handler.py` to `infrastructure/bus/query_handler.py`
    - Move `application/shared/handlers/` to `infrastructure/bus/handlers`
    - Move `application/shared/discovery/` to `infrastructure/bus/discovery`
2.  **Update Imports:** Update all import statements.
3.  **Run Tests:** Execute all tests.

---

## Phase 2: Relocating Behaviors

**Objective:** Move pipeline behaviors to the infrastructure layer, as they represent cross-cutting concerns applied to the bus.

**New Location:** `infrastructure/pipeline/`

### Step 2.1: Move Behavior Files

1.  **Create Directory:** Create `C:/Heijunka/infrastructure/pipeline/`.
2.  **Move Files:**
    - Move `application/shared/behaviors/behavior_interface.py` to `infrastructure/pipeline/behavior_interface.py`
    - Move `application/shared/behaviors/behavior_pipeline.py` to `infrastructure/pipeline/behavior_pipeline.py`
    - Move `application/shared/behaviors/logging_behavior.py` to `infrastructure/pipeline/logging_behavior.py`
    - Move `application/shared/behaviors/transaction_behavior.py` to `infrastructure/pipeline/transaction_behavior.py`
    - Move `application/shared/behaviors/validation_behavior.py` to `infrastructure/pipeline/validation_behavior.py`
3.  **Update Imports:** Update all import statements.
4.  **Run Tests:** Execute all tests.

---

## Phase 3: Decompose DTOs and Exceptions

**Objective:** Move generic DTOs and exceptions into the specific bounded contexts where they are used. This is the most critical phase for breaking domain-level coupling.

### Step 3.1: Analyze and Relocate `base_dto.py`

1.  **Analyze:** Determine which contexts use `base_dto.py`. It is likely that every context uses it.
2.  **Action:** **Duplicate** `base_dto.py` into each bounded context that needs it. For example:
    - `application/employee_management/dto/base_dto.py`
    - `application/schedule_management/dto/base_dto.py`
    - etc.
3.  **Update Imports:** Change the imports within each context to point to its local copy.
4.  **Run Tests:** Execute tests for each context as you make the change.

### Step 3.2: Analyze and Relocate Exceptions

1.  **Analyze:** For each exception in `application/shared/exceptions/`, identify which commands or queries can raise it.
2.  **Action:** Move each exception to the bounded context where it originates. If an exception is truly generic (e.g., `CommandValidationError`), it may be better suited for `infrastructure/bus/exceptions.py`.
    - `command_execution_error.py` -> `infrastructure/bus/exceptions.py`
    - `query_execution_error.py` -> `infrastructure/bus/exceptions.py`
    - `command_validation_error.py` -> `infrastructure/bus/exceptions.py`
    - `enhanced_exceptions.py` -> This needs careful analysis. It may need to be split up, with parts moving to different contexts.
3.  **Update Imports and Run Tests:** Follow the standard procedure.

---

## Phase 4: Final Cleanup

**Objective:** Remove the now-empty `application/shared` directory.

### Step 4.1: Verify Emptiness

- Ensure all subdirectories within `application/shared` are empty.

### Step 4.2: Delete Directory

- Delete the `C:/Heijunka/application/shared` directory from the project.
- Remove it from version control.

### Step 4.3: Final Verification

- Run the entire test suite one last time to confirm the success of the refactoring.
