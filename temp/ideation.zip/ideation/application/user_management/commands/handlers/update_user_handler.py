from application.shared.interfaces.command_handler import ICommandHandler
from application.shared.exceptions.command_validation_error import CommandExecutionError

from domain.contexts.user_management.repositories.interfaces.user_repository import UserRepositoryInterface
from domain.contexts.shared.entities import Role
from application.user_management.commands.update_user_command import UpdateUserCommand

class UpdateUserHandler(ICommandHandler[UpdateUserCommand, bool]):
    """
    Handles updates to a user's profile and roles, enforcing domain constraints
    and ensuring proper persistence.
    """

    def __init__(self, user_repository: UserRepositoryInterface):
        self._user_repository = user_repository

    async def handle(self, command: UpdateUserCommand) -> bool:
        user = await self._user_repository.get_by_id(command.user_id)
        if not user:
            raise CommandExecutionError(
                f"User with ID {command.user_id} not found.",
                command_type="UpdateUserCommand"
            )

        if command.email:
            user.email = command.email
        if command.first_name:
            user.first_name = command.first_name
        if command.last_name:
            user.last_name = command.last_name

        # Optional: Clear roles before re-adding
        user.clear_roles()
        for role_name in command.roles:
            user.add_role(Role(name=role_name))

        try:
            return await self._user_repository.save(user)
        except Exception as e:
            raise CommandExecutionError(
                f"Failed to update user '{user.username}'",
                command_type="UpdateUserCommand",
                inner_exception=e
            )
